use pizzeria;

db.createCollection("pizza", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "pizza",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "pizza_category": {
                    "bsonType": "object",
                    "properties": {
                        "category_name": {
                            "bsonType": "string"
                        },
                        "category_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "category_name",
                        "category_id"
                    ]
                },
                "pizza_type": {
                    "bsonType": "object",
                    "properties": {
                        "pizza_name": {
                            "bsonType": "string"
                        },
                        "image": {
                            "bsonType": "binData"
                        },
                        "price": {
                            "bsonType": "decimal"
                        },
                        "type_id": {
                            "bsonType": "objectId"
                        },
                        "category_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "pizza_name",
                        "image",
                        "price",
                        "type_id",
                        "category_id"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});