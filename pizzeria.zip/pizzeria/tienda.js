use pizzeria;

db.createCollection("tienda", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "tienda",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "store": {
                    "bsonType": "object",
                    "properties": {
                        "address": {
                            "bsonType": "object",
                            "properties": {
                                "street": {
                                    "bsonType": "string"
                                },
                                "building_num": {
                                    "bsonType": "string"
                                },
                                "zip": {
                                    "bsonType": "int"
                                },
                                "phone": {
                                    "bsonType": "int"
                                }
                            },
                            "additionalProperties": false,
                            "required": [
                                "street",
                                "building_num",
                                "zip",
                                "phone"
                            ]
                        },
                        "address_id": {
                            "bsonType": "objectId"
                        },
                        "city_id": {
                            "bsonType": "objectId"
                        },
                        "store_id": {
                            "bsonType": "objectId"
                        },
                        "employees": {
                            "bsonType": "array",
                            "additionalItems": true,
                            "items": {
                                "bsonType": "objectId"
                            }
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "address_id",
                        "city_id"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});