use pizzeria;

db.createCollection("tienda", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "tienda",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "store": {
                    "bsonType": "object",
                    "properties": {
                        "store_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false
                },
                "address": {
                    "bsonType": "object",
                    "properties": {
                        "street": {
                            "bsonType": "string"
                        },
                        "building_num": {
                            "bsonType": "string"
                        },
                        "zip": {
                            "bsonType": "int"
                        },
                        "phone": {
                            "bsonType": "int"
                        },
                        "city": {
                            "bsonType": "object",
                            "properties": {
                                "city_name": {
                                    "bsonType": "string"
                                }
                            },
                            "additionalProperties": false,
                            "required": [
                                "city_name"
                            ]
                        },
                        "province": {
                            "bsonType": "object",
                            "properties": {
                                "province_name": {
                                    "bsonType": "string"
                                }
                            },
                            "additionalProperties": false,
                            "required": [
                                "province_name"
                            ]
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "street",
                        "building_num",
                        "zip",
                        "phone"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});