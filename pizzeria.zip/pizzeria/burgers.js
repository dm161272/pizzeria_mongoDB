use pizzeria;

db.createCollection("burgers", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "burgers",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "burgers": {
                    "bsonType": "object",
                    "properties": {
                        "burger_name": {
                            "bsonType": "string"
                        },
                        "image": {
                            "bsonType": "binData"
                        },
                        "price": {
                            "bsonType": "decimal"
                        },
                        "burger_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "burger_name",
                        "image",
                        "price",
                        "burger_id"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});