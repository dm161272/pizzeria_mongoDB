use pizzeria;

db.createCollection("customer", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "customer",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "customer": {
                    "bsonType": "object",
                    "properties": {
                        "first_name": {
                            "bsonType": "string"
                        },
                        "last_name": {
                            "bsonType": "string"
                        },
                        "address": {
                            "bsonType": "object",
                            "properties": {
                                "street": {
                                    "bsonType": "string"
                                },
                                "building_num": {
                                    "bsonType": "string"
                                },
                                "apartment_num": {
                                    "bsonType": "int"
                                },
                                "zip": {
                                    "bsonType": "int"
                                },
                                "phone": {
                                    "bsonType": "int"
                                },
                                "city": {
                                    "bsonType": "object",
                                    "properties": {
                                        "city_name": {
                                            "bsonType": "string"
                                        }
                                    },
                                    "additionalProperties": false,
                                    "required": [
                                        "city_name"
                                    ]
                                },
                                "province": {
                                    "bsonType": "object",
                                    "properties": {
                                        "province_name": {
                                            "bsonType": "string"
                                        }
                                    },
                                    "additionalProperties": false,
                                    "required": [
                                        "province_name"
                                    ]
                                }
                            },
                            "additionalProperties": false,
                            "required": [
                                "street",
                                "building_num",
                                "zip",
                                "phone"
                            ]
                        },
                        "customer_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "first_name",
                        "last_name"
                    ]
                }
            },
            "additionalProperties": false,
            "required": [
                "customer"
            ]
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});