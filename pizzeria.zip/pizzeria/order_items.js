use pizzeria;

db.createCollection("order_items", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "order_items",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "order_items": {
                    "bsonType": "object",
                    "properties": {
                        "pizza_quantity": {
                            "bsonType": "array",
                            "additionalItems": true,
                            "items": [
                                {
                                    "bsonType": "string"
                                },
                                {
                                    "bsonType": "int"
                                }
                            ]
                        },
                        "burgers_quantity": {
                            "bsonType": "array",
                            "additionalItems": true,
                            "items": [
                                {
                                    "bsonType": "string"
                                },
                                {
                                    "bsonType": "int"
                                }
                            ]
                        },
                        "drinks_quantity": {
                            "bsonType": "array",
                            "additionalItems": true,
                            "items": [
                                {
                                    "bsonType": "string"
                                },
                                {
                                    "bsonType": "int"
                                }
                            ]
                        }
                    },
                    "additionalProperties": false
                },
                "order_id": {
                    "bsonType": "objectId"
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});