use pizzeria;

db.createCollection("location", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "location",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "province": {
                    "bsonType": "object",
                    "properties": {
                        "province_name": {
                            "bsonType": "string"
                        },
                        "province_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "province_name",
                        "province_id"
                    ]
                },
                "city": {
                    "bsonType": "object",
                    "properties": {
                        "city_name": {
                            "bsonType": "string"
                        },
                        "city_id": {
                            "bsonType": "objectId"
                        },
                        "province_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "city_name",
                        "province_id"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});