use pizzeria;

db.createCollection("orders", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "orders",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "order": {
                    "bsonType": "object",
                    "properties": {
                        "date": {
                            "bsonType": "date"
                        },
                        "delivery_type": {
                            "bsonType": "number"
                        },
                        "products_total": {
                            "bsonType": "int"
                        },
                        "price_total": {
                            "bsonType": "decimal"
                        },
                        "order_id": {
                            "bsonType": "objectId"
                        },
                        "customer_id": {
                            "bsonType": "objectId"
                        },
                        "delivery_date": {
                            "bsonType": "date"
                        },
                        "delivery_person": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "date",
                        "delivery_type",
                        "products_total",
                        "price_total",
                        "order_id",
                        "customer_id"
                    ]
                },
                "products": {
                    "bsonType": "array",
                    "additionalItems": true,
                    "items": [
                        {
                            "bsonType": "objectId"
                        },
                        {
                            "bsonType": "objectId"
                        },
                        {
                            "bsonType": "objectId"
                        }
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});