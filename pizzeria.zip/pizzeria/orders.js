use pizzeria;

db.createCollection("orders", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "orders",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "order": {
                    "bsonType": "object",
                    "properties": {
                        "date": {
                            "bsonType": "date"
                        },
                        "delivery_type": {
                            "bsonType": "number"
                        },
                        "products_total_quantity": {
                            "bsonType": "int"
                        },
                        "price_total": {
                            "bsonType": "decimal"
                        },
                        "order_id": {
                            "bsonType": "objectId"
                        },
                        "customer_id": {
                            "bsonType": "objectId"
                        },
                        "delivery_date": {
                            "bsonType": "date"
                        },
                        "employee_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "date",
                        "delivery_type",
                        "products_total_quantity",
                        "price_total",
                        "order_id",
                        "customer_id"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});