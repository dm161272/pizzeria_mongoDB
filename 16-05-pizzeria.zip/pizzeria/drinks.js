use pizzeria;

db.createCollection("drinks", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "drinks",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "drinks": {
                    "bsonType": "object",
                    "properties": {
                        "drink_name": {
                            "bsonType": "string"
                        },
                        "image": {
                            "bsonType": "binData"
                        },
                        "drink_id": {
                            "bsonType": "objectId"
                        },
                        "price": {
                            "bsonType": "decimal"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "drink_name",
                        "image",
                        "drink_id",
                        "price"
                    ]
                }
            },
            "additionalProperties": false
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});