use pizzeria;

db.createCollection("employee", {
    "capped": false,
    "validator": {
        "$jsonSchema": {
            "bsonType": "object",
            "title": "employee",
            "properties": {
                "_id": {
                    "bsonType": "objectId"
                },
                "employee": {
                    "bsonType": "object",
                    "properties": {
                        "first_name": {
                            "bsonType": "string"
                        },
                        "last_name": {
                            "bsonType": "string"
                        },
                        "nif": {
                            "bsonType": "string"
                        },
                        "phone": {
                            "bsonType": "string"
                        },
                        "employee_type": {
                            "bsonType": "int"
                        },
                        "employee_id": {
                            "bsonType": "objectId"
                        },
                        "store_id": {
                            "bsonType": "objectId"
                        }
                    },
                    "additionalProperties": false,
                    "required": [
                        "first_name",
                        "last_name",
                        "nif",
                        "phone",
                        "employee_type",
                        "employee_id",
                        "store_id"
                    ]
                }
            },
            "additionalProperties": false,
            "required": [
                "employee"
            ]
        }
    },
    "validationLevel": "off",
    "validationAction": "warn"
});